// ConfigManager handles custom arguments, initial data, and environment variables for N3Logic debug sessions
import { DebugProtocol } from '@vscode/debugprotocol';

export interface N3LogicConfig {
  customArgs?: Record<string, any>;
  initialData?: string;
  env?: Record<string, string>;
}

export class ConfigManager {
  private config: N3LogicConfig = {};

  public loadFromLaunchArgs(args: DebugProtocol.LaunchRequestArguments): void {
    // Accept customArgs, initialData, and env from launch.json (using index access)
    const anyArgs = args as any;
    if (anyArgs.customArgs && typeof anyArgs.customArgs === 'object') {
      this.config.customArgs = anyArgs.customArgs;
    }
    if (typeof anyArgs.initialData === 'string') {
      this.config.initialData = anyArgs.initialData;
    }
    if (anyArgs.env && typeof anyArgs.env === 'object') {
      this.config.env = anyArgs.env as Record<string, string>;
    }
  }

  public getCustomArgs(): Record<string, any> | undefined {
    return this.config.customArgs;
  }

  public getInitialData(): string | undefined {
    return this.config.initialData;
  }

  public getEnv(): Record<string, string> | undefined {
    return this.config.env;
  }
}
