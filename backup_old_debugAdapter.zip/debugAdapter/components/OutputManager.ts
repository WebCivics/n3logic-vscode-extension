// OutputManager handles sending output and logging to the VS Code Debug Console
import { OutputEvent } from '@vscode/debugadapter';

export class OutputManager {
  private sendEvent: (event: OutputEvent) => void;

  constructor(sendEvent: (event: OutputEvent) => void) {
    this.sendEvent = sendEvent;
  }

  public log(message: string): void {
    this.sendEvent(new OutputEvent(message));
  }

  public error(message: string): void {
    this.sendEvent(new OutputEvent(`[Error] ${message}\n`));
  }

  public evalResult(result: string): void {
    this.sendEvent(new OutputEvent(`[Result] ${result}\n`));
  }
}
