// CustomDebugUIManager handles custom debug UI features for the N3Logic debug adapter
import { OutputEvent } from '@vscode/debugadapter';

export class CustomDebugUIManager {
  private sendEvent: (event: OutputEvent) => void;

  constructor(sendEvent: (event: OutputEvent) => void) {
    this.sendEvent = sendEvent;
  }

  // Example: send a custom command message to the Debug Console
  public sendCustomCommandInfo(command: string, description: string): void {
    this.sendEvent(new OutputEvent(`[Command] ${command}: ${description}\n`));
  }

  // Example: send an inline value (for future inline value support)
  public sendInlineValue(variable: string, value: string): void {
    this.sendEvent(new OutputEvent(`[Inline] ${variable} = ${value}\n`));
  }

  // Example: send a tooltip message
  public sendTooltip(message: string): void {
    this.sendEvent(new OutputEvent(`[Tooltip] ${message}\n`));
  }
}
