import { ConfigManager } from './components/ConfigManager';

import { CustomDebugUIManager } from './components/CustomDebugUIManager';
import { ExceptionManager } from './components/ExceptionManager';

import {
  DebugSession,
  InitializedEvent,
  TerminatedEvent,
  StoppedEvent,
  BreakpointEvent,
  OutputEvent
} from '@vscode/debugadapter';
import { DebugProtocol } from '@vscode/debugprotocol';
import { StepManager } from './components/StepManager';
import { VariableManager } from './components/VariableManager';
import { StackManager } from './components/StackManager';
import { OutputManager } from './components/OutputManager';



interface BreakpointInfo {
  line: number;
  verified: boolean;
}

export class N3LogicDebugSession extends DebugSession {
  private breakpoints: { [file: string]: BreakpointInfo[] } = {};
  private stepManager = new StepManager();
  private variableManager = new VariableManager();
  private stackManager = new StackManager();
  private outputManager: OutputManager;
  private exceptionManager: ExceptionManager;
  private customDebugUIManager: CustomDebugUIManager;
  private configManager: ConfigManager;

  public constructor() {
    super();
    // Bind OutputManager, ExceptionManager, and CustomDebugUIManager to this.sendEvent
    this.outputManager = new OutputManager(this.sendEvent.bind(this));
    this.exceptionManager = new ExceptionManager(this.sendEvent.bind(this));
    this.customDebugUIManager = new CustomDebugUIManager(this.sendEvent.bind(this));
  this.configManager = new ConfigManager();
  }

  protected initializeRequest(
    response: DebugProtocol.InitializeResponse,
    args: DebugProtocol.InitializeRequestArguments
  ): void {
    response.body = response.body || {};
    response.body.supportsConfigurationDoneRequest = true;
    this.sendResponse(response);
    this.sendEvent(new InitializedEvent());
  }

  protected setBreakpointsRequest(
    response: DebugProtocol.SetBreakpointsResponse,
    args: DebugProtocol.SetBreakpointsArguments
  ): void {
    const path = args.source.path || '';
    const clientLines = args.lines || [];
    const bps: BreakpointInfo[] = [];
    const breakpoints: DebugProtocol.Breakpoint[] = [];

    for (const line of clientLines) {
      const bp: BreakpointInfo = { line, verified: true };
      bps.push(bp);
      breakpoints.push({
        verified: true,
        line: line
      });
    }
    this.breakpoints[path] = bps;
    response.body = { breakpoints };
    this.sendResponse(response);
    for (const bp of breakpoints) {
      this.sendEvent(new BreakpointEvent('changed', bp));
    }
  }

  protected launchRequest(
    response: DebugProtocol.LaunchResponse,
    args: DebugProtocol.LaunchRequestArguments
  ): void {
    // Load configuration enhancements
    this.configManager.loadFromLaunchArgs(args);
    const customArgs = this.configManager.getCustomArgs();
    const initialData = this.configManager.getInitialData();
    const env = this.configManager.getEnv();

    this.outputManager.log('N3Logic Debugger started\n');
    // Use initialData to pre-populate the variable manager (simulate loading data)
    if (initialData) {
      this.variableManager.setVariable('initialData', initialData);
      this.outputManager.log(`[Config] Loaded Initial Data: ${initialData}\n`);
    }
    // Use customArgs to set up execution options (simulate custom behavior)
    if (customArgs) {
      Object.keys(customArgs).forEach(key => {
        this.variableManager.setVariable(key, customArgs[key]);
      });
      this.outputManager.log(`[Config] Custom Args Applied: ${JSON.stringify(customArgs)}\n`);
    }
    // Use env to simulate environment variable setup (log for now)
    if (env) {
      this.outputManager.log(`[Config] Environment Variables: ${JSON.stringify(env)}\n`);
    }

    // Example: send custom command info, inline value, and tooltip
    this.customDebugUIManager.sendCustomCommandInfo('n3logic.stepToRule', 'Step to the next N3Logic rule');
    this.customDebugUIManager.sendInlineValue('varX', String(this.variableManager.getVariable('varX') ?? '42'));
    this.customDebugUIManager.sendTooltip('Hover over a rule to see details.');
    // Example: simulate an exception on launch for demonstration
    // this.exceptionManager.reportException('Example N3Logic execution error');
    this.stepManager.reset();
    this.variableManager.reset();
    this.stackManager.reset();
    this.sendResponse(response);
    this.sendEvent(new StoppedEvent('entry', 1));
  }

  protected nextRequest(
    response: DebugProtocol.NextResponse,
    args: DebugProtocol.NextArguments
  ): void {
    const idx = this.stepManager.next();
  this.outputManager.log(`Stepped to statement #${idx}\n`);
    this.sendEvent(new StoppedEvent('step', 1));
    this.sendResponse(response);
  }

  protected continueRequest(
    response: DebugProtocol.ContinueResponse,
    args: DebugProtocol.ContinueArguments
  ): void {
  this.outputManager.log('Continuing execution...\n');
    this.sendEvent(new TerminatedEvent());
    this.sendResponse(response);
  }

  protected scopesRequest(
    response: DebugProtocol.ScopesResponse,
    args: DebugProtocol.ScopesArguments
  ): void {
    response.body = {
      scopes: [
        {
          name: 'Local',
          variablesReference: 1,
          expensive: false
        }
      ]
    };
    this.sendResponse(response);
  }

  protected variablesRequest(
    response: DebugProtocol.VariablesResponse,
    args: DebugProtocol.VariablesArguments
  ): void {
    const vars = this.variableManager.getAllVariables();
    response.body = {
      variables: Object.keys(vars).map(name => ({
        name,
        value: String(vars[name]),
        variablesReference: 0
      }))
    };
    this.sendResponse(response);
  }

  protected stackTraceRequest(
    response: DebugProtocol.StackTraceResponse,
    args: DebugProtocol.StackTraceArguments
  ): void {
    const stack = this.stackManager.getStack();
    response.body = {
      stackFrames: stack.map((frame, i) => ({
        id: i + 1,
        name: frame.name,
        line: frame.line,
        column: 1,
        source: undefined
      })),
      totalFrames: stack.length
    };
    this.sendResponse(response);
  }

  protected threadsRequest(
    response: DebugProtocol.ThreadsResponse
  ): void {
    response.body = {
      threads: [{ id: 1, name: 'Main Thread' }]
    };
    this.sendResponse(response);
  }
}

DebugSession.run(N3LogicDebugSession);
